@extends('templates.geral')

@section('title','Home')

@section('site')
    <h3>Bem vindo ao Margem Certa</h3>
    <p>Aqui você compara seu preço com os concorrentes próximo.</p>
    <div class="row">
        <div style="display:flex;justify-content: center;">
        <h3><b>Já imaginou aumentar sua margem e ainda continuar sendo o mais barato da região?</b></h3>
        </div>
    </div>
    
@endsection 

