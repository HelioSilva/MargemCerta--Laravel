<?php $__env->startSection('title','Todos Produtos'); ?>


<?php $__env->startSection('site'); ?>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h1>Listagem de Produtos</h1>
            <?php if($message = Session::get('success')): ?>
                <div id="sucesso" class="alert alert-success collapse">
                    <a href="#" class="close" data-dismiss="alert">&times;</a>
                    <strong id="message"><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>

            <hr>
            <div class="pull-right">
                <a class="btn btn-sm btn-success" href="<?php echo e(route('produtos.create')); ?>">Novo Produto</a>
            </div>       

            <script>
             function exibir(){
                    $('#sucesso').show('fade');	
                                        setTimeout(function(){
                                            $('#sucesso').hide('fade');
                                        },2000);
                }
            </script>

            <?php if($message = Session::get('success')): ?>
                <?php 
                 echo "<script>exibir();</script>";
                 ?>
                <!-- <div class="alert alert-success">
                <p><?php echo e($message); ?></p>
                </div> -->
            <?php endif; ?>

            <table class="table table-bordered">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Barras</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Custo</th>
                    <th scope="col">Vendas</th>
                    <th scope="col">Margem Bruta</th>
                    <th scope="col">Ações</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($produto->id); ?></th>
                        <td><?php echo e($produto->barras); ?></td>
                        <td><?php echo e($produto->nome); ?></td>
                        <td><?php echo e($produto->custo); ?></td>
                        <td><?php echo e($produto->preco); ?></td>
                        <td><?php echo e($produto->margem); ?></td>
                        <td>
                            <a href="/produtos/<?php echo e($produto->id); ?>" class="btn btn-xs btn-info">Exibir</a>
                            <a href="/produtos/<?php echo e($produto->id); ?>/edit" class="btn btn-xs btn-primary">Editar</a>
                            <form style="display: inline" action="<?php echo e(url('/produtos', ['id' => $produto->id])); ?>" method="post">
                                <?php echo method_field('delete'); ?>

                                <?php echo csrf_field(); ?>

                                <button class="btn btn-xs btn-danger" type="submit">Delete</button>
                            </form>
                           
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('templates.geral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>