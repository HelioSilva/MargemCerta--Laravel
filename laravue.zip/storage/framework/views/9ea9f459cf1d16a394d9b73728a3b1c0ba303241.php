                <!-- <div class="form-group">
                    <label for="exampleInputEmail1">Codigo interno</label>
                    <input type="text" class="form-control" placeholder="Código">
                </div> -->
                <div class="form-group">
                    <label for="exampleInputEmail1">Codigo de barras</label>
                    <?php if(isset($produto)): ?>
                    <input type="number" value="<?php echo e($produto->barras); ?>" required class="form-control"  maxlength="14" placeholder="Digite o código de barras" name="barras">
                    <?php else: ?>
                    <input type="number" required class="form-control"  maxlength="14" placeholder="Digite o código de barras" name="barras">
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Nome do Produto</label>
                    <?php if(isset($produto)): ?>
                    <input type="text" value="<?php echo e($produto->nome); ?>" required class="form-control" style="text-transform:uppercase"  placeholder="Digite o nome do produto" name="nome">
                    <?php else: ?>
                    <input type="text" required class="form-control" style="text-transform:uppercase"  placeholder="Digite o nome do produto" name="nome">
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Preço Custo</label>
                    <?php if(isset($produto)): ?>
                    <input type="number" value="<?php echo e($produto->custo); ?>" id="valores" required step=0.01 class="form-control valores" placeholder="Custo" name="custo">
                    <?php else: ?>
                    <input type="number" id="valores" required step=0.01 class="form-control valores" placeholder="Custo" name="custo">
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Preço Venda</label>
                    <?php if(isset($produto)): ?>
                    <input type="number" value="<?php echo e($produto->preco); ?>" required step=0.01 class="form-control valores" placeholder="Venda" name="preco">
                    <?php else: ?>
                    <input type="number" required step=0.01 class="form-control valores" placeholder="Venda" name="preco">
                    <?php endif; ?>
                </div>
                
                