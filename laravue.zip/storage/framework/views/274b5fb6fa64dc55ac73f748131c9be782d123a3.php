<?php $__env->startSection('title','Novo'); ?>


<?php $__env->startSection('site'); ?>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h1>Edição Produto</h1>
            <div class="row">
                <div class="col-lg-12">
                <div class="pull-right">
                <a class="btn btn-sm btn-primary" href="<?php echo e(route('produtos.index')); ?>">Voltar</a>
                </div>
                </div>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <hr>

            <form action="<?php echo e(url('/produtos', ['id' => $produto->id])); ?>" method="post" >
            <?php echo method_field('put'); ?>

            <?php echo csrf_field(); ?>

               <?php echo $__env->make('produto.formProduto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
               <button type="submit" class="btn btn-primary">Aplicar Alterações</button>
            </form>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.geral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>