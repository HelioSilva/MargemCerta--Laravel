<?php $__env->startSection('title','Exibir'); ?>

<?php $__env->startSection('site'); ?>

<div class="col-md-8 col-md-offset-2">
<h1>Detalhes do produto</h1>
  <div class="row">
      <div class="col-lg-12">
          <div class="pull-right">
          <a class="btn btn-sm btn-primary" href="<?php echo e(route('produtos.index')); ?>">Voltar</a>
          </div>
      </div>
  </div>
   <hr>

  <div class="row">
    <div class="col-xs-12">
      <div class="form-group">
        <strong>Codigo : </strong>
        <?php echo e($produto->id); ?>

      </div>
    </div>
    <div class="col-xs-12">
      <div class="form-group">
        <strong>Codigo Barras : </strong>
        <?php echo e($produto->barras); ?>

      </div>
    </div>
    <div class="col-xs-12">
      <div class="form-group">
        <strong>Nome  : </strong>
        <?php echo e($produto->nome); ?>

      </div>
    </div>
    <div class="col-xs-12">
      <div class="form-group">
        <strong>Preço Custo  : </strong>
        <?php echo e($produto->custo); ?>

      </div>
    </div>
    <div class="col-xs-12">
      <div class="form-group">
        <strong>Preço venda  : </strong>
        <?php echo e($produto->preco); ?>

      </div>
    </div>

  </div>

  </div>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.geral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>