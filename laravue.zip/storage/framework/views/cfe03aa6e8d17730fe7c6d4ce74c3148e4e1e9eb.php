<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>MargemCerta - <?php echo $__env->yieldContent('title'); ?></title>


    <link rel="stylesheet" type="text/css" href="/css/app.css">  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>

    <?php echo $__env->make('templates.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

    <div class="container">
        <?php echo $__env->yieldContent('site'); ?>;
    </div>
    
    <script>
      <?php echo $__env->yieldContent('script'); ?>
    </script>
    <script src="/js/app.js"></script>
</body>
</html>