<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('site'); ?>
    <h3>Bem vindo ao Margem Certa</h3>
    <p>Aqui você compara seu preço com os concorrentes próximo.</p>
    <div class="row">
        <div style="display:flex;justify-content: center;">
        <h3><b>Já imaginou aumentar sua margem e ainda continuar sendo o mais barato da região?</b></h3>
        </div>
    </div>
    
<?php $__env->stopSection(); ?> 


<?php echo $__env->make('templates.geral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>