<?php $__env->startSection('title','Novo'); ?>


<?php $__env->startSection('site'); ?>

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h1>Novo Produto</h1>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <hr>

            <form action="<?php echo e(route('produtos.store')); ?>" method="post" autocomplete="off">
                <?php echo csrf_field(); ?>

                <?php echo $__env->make('produto.formProduto', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
               <button type="submit" class="btn btn-primary">Inserir</button>
            </form>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    $(document).ready(function () { 
            var $seuCampoCpf = $("#valores");
            $seuCampoCpf.mask('000.000.000-00', {reverse: true});
        });
<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.geral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>